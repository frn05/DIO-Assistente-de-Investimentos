import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from extrair_clientes import extrair_clientes, parse_brl

class TestExtracao(unittest.TestCase):
    def test_parse_saldo_brasileiro(self):
        self.assertEqual(parse_brl("R$ 12.500,00"), 12500.0)
        self.assertEqual(parse_brl("R$ 850,50"), 850.5)

    def test_extrai_cliente(self):
        html = """<table id="clientes"><tbody><tr>
        <td class="nome">Ana Silva</td><td class="email">ana@email.com</td>
        <td class="saldo">R$ 12.500,00</td><td class="perfil">Conservador</td>
        </tr></tbody></table>"""
        self.assertEqual(extrair_clientes(html), [{
            "nome": "Ana Silva", "email": "ana@email.com",
            "saldo": 12500.0, "perfil": "Conservador"
        }])

    def test_falha_sem_tabela(self):
        with self.assertRaises(ValueError):
            extrair_clientes("<html><body>sem tabela</body></html>")

if __name__ == "__main__":
    unittest.main()
