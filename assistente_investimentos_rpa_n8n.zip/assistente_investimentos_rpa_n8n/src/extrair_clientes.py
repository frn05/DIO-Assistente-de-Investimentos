#!/usr/bin/env python3
"""Extrai clientes fictícios da página HTML e envia o lote ao webhook do n8n."""
from __future__ import annotations
import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

import requests
from bs4 import BeautifulSoup

DEFAULT_URL = "https://digitalinnovationone.github.io/dio-lab-assistente-investimentos-rpa-n8n/"
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output" / "clientes_extraidos.json"
PERFIS = {"conservador", "moderado", "arrojado"}

def parse_brl(value: str) -> float:
    """Converte 'R$ 12.500,00' ou '12500,00' para float."""
    cleaned = re.sub(r"[^\d,.-]", "", value.strip())
    if "," in cleaned:
        cleaned = cleaned.replace(".", "").replace(",", ".")
    try:
        return float(cleaned)
    except ValueError as exc:
        raise ValueError(f"Saldo inválido: {value!r}") from exc

def extrair_clientes(html: str) -> list[dict[str, Any]]:
    soup = BeautifulSoup(html, "html.parser")
    rows = soup.select("#clientes tbody tr")
    if not rows:
        raise ValueError("Nenhum cliente encontrado em '#clientes tbody tr'. Confira a URL e a estrutura HTML.")
    clientes = []
    for idx, row in enumerate(rows, start=1):
        def cell(class_name: str) -> str:
            node = row.select_one(f".{class_name}")
            return node.get_text(" ", strip=True) if node else ""
        nome, email, saldo_txt, perfil = (cell(k) for k in ("nome", "email", "saldo", "perfil"))
        perfil = perfil.strip().capitalize()
        if not nome or not email or not saldo_txt or perfil.lower() not in PERFIS:
            raise ValueError(f"Registro {idx} incompleto ou perfil desconhecido: {row.get_text(' ', strip=True)}")
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            raise ValueError(f"E-mail inválido no registro {idx}: {email}")
        clientes.append({"nome": nome, "email": email, "saldo": parse_brl(saldo_txt), "perfil": perfil})
    return clientes

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--clientes-url", default=os.getenv("CLIENTES_URL", DEFAULT_URL))
    parser.add_argument("--enviar", action="store_true", help="Envia os dados ao webhook configurado em N8N_WEBHOOK_URL.")
    parser.add_argument("--saida", default=str(OUTPUT), help="Caminho do JSON de saída.")
    args = parser.parse_args()
    try:
        response = requests.get(args.clientes_url, timeout=30, headers={"User-Agent": "DIO-InvestmentAssistant/1.0"})
        response.raise_for_status()
        clientes = extrair_clientes(response.text)
        payload = {"clientes": clientes}
        output = Path(args.saida)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"Extração concluída: {len(clientes)} clientes. JSON salvo em: {output}")
        if args.enviar:
            webhook = os.getenv("N8N_WEBHOOK_URL", "").strip()
            if not webhook:
                raise RuntimeError("Defina N8N_WEBHOOK_URL antes de usar --enviar.")
            result = requests.post(webhook, json=payload, timeout=60)
            result.raise_for_status()
            print("Webhook executado com sucesso.")
            try:
                print(json.dumps(result.json(), ensure_ascii=False, indent=2))
            except requests.exceptions.JSONDecodeError:
                print(result.text[:2000])
        else:
            print("Modo local: nenhum dado foi enviado. Use --enviar após configurar o webhook.")
        return 0
    except (requests.RequestException, ValueError, RuntimeError) as exc:
        print(f"ERRO: {exc}", file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
